﻿namespace WebApplication1.Models
{
    public class userModel
    {
        public int PersonID { get; set; }
        public string ?Username { get; set; }
        public string ?Förnamn { get; set; }
        public string ?Efternamn { get; set; }
        public string ?Password { get; set; }
        public string ?Picture { get; set; }
    }
}
