using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;
using WebApplication1.Models;
using System.Diagnostics.Eventing.Reader;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment environment;

        public HomeController(IWebHostEnvironment env)
        {
            environment = env;
        }

        private string GetConnectionString(string databaseFileName)
        {
            return environment.IsDevelopment()
                ? @$"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={environment.ContentRootPath}\{databaseFileName};Integrated Security=True;Connect Timeout=15"
                : @$"Data Source=.\SQLEXPRESS;Integrated Security=SSPI;AttachDBFilename={environment.ContentRootPath}{databaseFileName};User Instance=true;Connect Timeout=15";
        }

        [HttpGet]

        public ActionResult Create()
        {
            return View();
        }


        public ActionResult SearchWindow()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(IFormFile file)
        {
            using (SqlConnection connection = new SqlConnection(GetConnectionString("testDB.mdf")))
            {
                connection.Open();
                string query = "INSERT INTO person (F�rnamn, Efternamn, Username, PSW, picture) VALUES(@Firstname, @Lastname, @Usern, @Pswd, @Pic)";
                SqlCommand sqlCmd = new SqlCommand(query, connection);
                sqlCmd.Parameters.AddWithValue("@Firstname", Request.Form["F�rnamn"].ToString());
                sqlCmd.Parameters.AddWithValue("@Lastname", Request.Form["Efternamn"].ToString());
                sqlCmd.Parameters.AddWithValue("@Usern", Request.Form["Username"].ToString());
                sqlCmd.Parameters.AddWithValue("@Pswd", Request.Form["Mats"].ToString());

                if (file == null)
                {
                    sqlCmd.Parameters.AddWithValue("@Pic", "dummy.png");
                    sqlCmd.ExecuteReader();
                }
                else
                {
                    sqlCmd.Parameters.AddWithValue("@Pic", file.FileName);
                    var filePath = Path.Combine(this.environment.ContentRootPath, "wwwroot/Bilder/", file.FileName);
                    using var stream = System.IO.File.Create(filePath);
                    file.CopyTo(stream);
                    sqlCmd.ExecuteReader();

                }
            }
            return RedirectToAction("Index");
        }

      


        public ActionResult Edit(int id)
        {
           
                userModel userModel = new userModel();
                DataTable LocalTbl = new DataTable();
                using (SqlConnection sqlCon = new SqlConnection(GetConnectionString("testDB.mdf")))
                {
                    sqlCon.Open();
                    string query = "SELECT * FROM person WHERE PersonID = @Id";
                    SqlDataAdapter sqlDa = new SqlDataAdapter(query, sqlCon);
                    sqlDa.SelectCommand.Parameters.AddWithValue("@Id", id);
                    sqlDa.Fill(LocalTbl);
                }
                if (LocalTbl.Rows.Count == 1)
                {
                    userModel.PersonID = Convert.ToInt32(LocalTbl.Rows[0][0].ToString());
                    userModel.Username = LocalTbl.Rows[0][3].ToString();
                    userModel.Password = LocalTbl.Rows[0][4].ToString();
                    userModel.F�rnamn = LocalTbl.Rows[0][1].ToString();
                    userModel.Efternamn = LocalTbl.Rows[0][2].ToString();
                    userModel.Picture = LocalTbl.Rows[0][5].ToString();
                    return View(userModel);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            
          
            
        }


        [HttpPost]
        public IActionResult Edit(userModel userModel, IFormFile file)
        {
            using (SqlConnection sqlConn = new SqlConnection(GetConnectionString("testDB.mdf")))
            {
                sqlConn.Open();
                if (file != null)
                {
                    string query = "UPDATE person SET F�rnamn = @Firstname, Efternamn = @Lastname, Username = @Usern, PSW = @Pswd, Picture = @Bild WHERE PersonID = @Id";
                    SqlCommand sqlCmd = new SqlCommand(query, sqlConn);
                    sqlCmd.Parameters.AddWithValue("@Id", Convert.ToInt32(Request.Form["PersonID"].ToString()));
                    sqlCmd.Parameters.AddWithValue("@Firstname", Request.Form["F�rnamn"].ToString());
                    sqlCmd.Parameters.AddWithValue("@Lastname", Request.Form["Efternamn"].ToString());
                    sqlCmd.Parameters.AddWithValue("@Usern", Request.Form["Username"].ToString());
                    sqlCmd.Parameters.AddWithValue("@Pswd", Request.Form["PSW"].ToString());
                    var filePath = Path.Combine(this.environment.ContentRootPath, "wwwroot/Bilder/", file.FileName);
                    using var stream = System.IO.File.Create(filePath);
                    file.CopyTo(stream);
                    sqlCmd.Parameters.AddWithValue("@Bild", file.FileName);
                    sqlCmd.ExecuteReader();
                }
                else
                {
                    string query = "UPDATE person SET F�rnamn = @Firstname, Efternamn = @Lastname, Username = @Usern, PSW = @Pswd WHERE PersonID = @Id";
                    SqlCommand sqlCmd = new SqlCommand(query, sqlConn);
                    sqlCmd.Parameters.AddWithValue("@Id", Convert.ToInt32(Request.Form["id"].ToString()));
                    sqlCmd.Parameters.AddWithValue("@Firstname", Request.Form["F�rnamn"].ToString());
                    sqlCmd.Parameters.AddWithValue("@Lastname", Request.Form["Efternamn"].ToString());
                    sqlCmd.Parameters.AddWithValue("@Usern", Request.Form["Username"].ToString());
                    sqlCmd.Parameters.AddWithValue("@Pswd", Request.Form["PSW"].ToString());
                    sqlCmd.ExecuteReader();
                }
            }
            return RedirectToAction("Index");
        }

        public ActionResult LogIn()
        {

            return View();
        }


        public const string UserID = "_personID";
        public const string UserName = "_Username";
        public const string Inloggad = "_InloggStatus";


        [HttpPost]
        public IActionResult LogIn_check()
        {
            DataTable person = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(GetConnectionString("testDB.mdf")))
            {
                sqlCon.Open();
                string query = "SELECT * FROM person WHERE Username = @Username AND PSW = @Password";
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, sqlCon);
                sqlDa.SelectCommand.Parameters.AddWithValue("@Username", Request.Form["Username"].ToString());
                sqlDa.SelectCommand.Parameters.AddWithValue("@Password", Request.Form["Mats"].ToString());

                sqlDa.Fill(person);
            }

            if (person.Rows.Count > 0)
            {
                HttpContext.Session.SetInt32(UserID, (int)person.Rows[0]["PersonID"]);
                HttpContext.Session.SetString(UserName, (string)person.Rows[0]["Username"]);
                HttpContext.Session.SetString(Inloggad, "yes");
                ViewData["personID"] = HttpContext.Session.GetInt32("_personID");
                ViewData["Username"] = HttpContext.Session.GetString("_Uname");
                ViewData["text"] = HttpContext.Session.GetString("_InloggStatus");
                ViewData["text"] = "logged In";
                return RedirectToAction("Index");

            }
            else
            {
                ViewData["text"] = "ej inloggad";
                return RedirectToAction("LogIn");
            }
        }

        public const string AdminUID = "_AdminUID";
        public const string AdminName = "_AdminName";
        public const string AdminInloggad = "_AdminInloggStatus";

        [HttpPost]
        public IActionResult LogIn_check_Admin()
        {
            DataTable Admin = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(GetConnectionString("testDB.mdf")))
            {
                sqlCon.Open();
                string query = "SELECT * FROM Admin WHERE AdminUser = @AdminUser AND AdminPsw = @AdminPsw";
                SqlDataAdapter sqlDa = new SqlDataAdapter(query, sqlCon);
                sqlDa.SelectCommand.Parameters.AddWithValue("@AdminUser", Request.Form["AdminUser"].ToString());
                sqlDa.SelectCommand.Parameters.AddWithValue("@AdminPsw", Request.Form["AdminPsw"].ToString());

                sqlDa.Fill(Admin);
            }
            if (Admin.Rows.Count > 0)
            {
                HttpContext.Session.SetInt32(AdminUID, (int)Admin.Rows[0]["AdminID"]);
                HttpContext.Session.SetString(AdminName, (string)Admin.Rows[0]["AdminUser"]);
                HttpContext.Session.SetString(AdminInloggad, "yes");

                ViewData["AdminUID"] = HttpContext.Session.GetInt32("_AdminUID");
                ViewData["AdminName"] = HttpContext.Session.GetString("_AdminName");
                ViewData["text"] = HttpContext.Session.GetString("_InloggStatus");
                ViewData["text"] = "logged In";
                return RedirectToAction("Index");

            }
            else
            {
                ViewData["text"] = "ej inloggad";
                return RedirectToAction("LogIn");
            }
        }

        public ActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Index()
        {
            DataTable localTbl = new DataTable();
            using (SqlConnection connection = new SqlConnection(GetConnectionString("testDB.mdf")))
            {
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM person", connection);
                connection.Open();
                sqlDa.Fill(localTbl);
            }

            return View(localTbl);
        }

        public ActionResult Delete(int id)
        {
            using (SqlConnection sqlConn = new SqlConnection(GetConnectionString("testDB.mdf")))
            {
                sqlConn.Open();

                string query = "DELETE FROM person WHERE PersonID = @Id";
                SqlCommand sqlCmd = new SqlCommand(query, sqlConn);
                sqlCmd.Parameters.AddWithValue("@Id", id);
                sqlCmd.ExecuteReader();
            }
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }


    }
}
